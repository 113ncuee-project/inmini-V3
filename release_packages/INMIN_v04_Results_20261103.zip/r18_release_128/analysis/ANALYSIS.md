# INMIN v0.4 數字審計

Audit passed: True
Run status: completed

|Method|Full PPA|Cost 改善 %|Latency 改善 %|Energy 改善 %|PPA/min（搜尋）|最後10步 entropy|
|---|---:|---:|---:|---:|---:|---:|
|replay_rl|128|9.135002|20.934283|30.218662|7.017210|0.701171|

## Policy 的未見候選驗證

```json
{
  "status": "not_run"
}
```

共同 query/time 預算的結果見 equal_queries.csv / equal_time.csv；全步數值曲線見 curves.csv。
沒有產生圖片。未見候選排序與 feature mask 只是模型行為證據；實際搜尋勝負以相同預算的完整 PPA 結果為準。
SGD 更新次數不是 PPA 次數；內層最佳化、warmup 與 RL 選擇的效果必須分開歸因。
