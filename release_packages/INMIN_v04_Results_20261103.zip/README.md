# Numeric review bundle

Read docs/INMIN_V04_RESULTS.md first. This bundle contains summaries, selected
complete mappings, actual trial logs, query/time ledgers, numerical curves,
source manifests and initial/final Q models. It omits intermediate policy
checkpoints, full candidate pools and most redundant per-trial trace artifacts.
The full historical evidence is INMIN_v04_Evidence_20261103.zip; runnable current
source, matching native binary and portable inputs are INMIN_v04_Code_20261103.zip.

All PPA is uncalibrated analytical estimation. The Tangram-style adapter is the
project baseline. RL selection and bottleneck-feature superiority are not
established by this single-workload/RNG result. The EDP archive recommendation
is one complete measured design selected after Balanced training. No images.
Development/interrupted cases remain visible and must not be mistaken for
completed method comparisons. No control-arm labels trained the search policy.
