# Oracle exactness and attribution controls

Full PPA (separate from search): 8
Source stable: True

|Variant|Full PPA|Feasible|Cost improvement %|Latency ms|Energy mJ|Wall s|
|---|---:|---|---:|---:|---:|---:|
|original|1|True|0.0|11.818170|18.438092|10.477382|
|dataflow_inner_only|1|True|0.0|11.818170|18.438092|5.997480|
|retention_auto_only|1|True|1.5751840034605724|11.285378|17.343812|5.634508|
|dataflow_and_retention_inner_only|1|True|1.5751840034605724|11.285378|17.343812|5.635220|

Same source, same exact seed, fresh evaluators, alternating order, no profiler.
Median full oracle speedup: 2.3972281341451973
