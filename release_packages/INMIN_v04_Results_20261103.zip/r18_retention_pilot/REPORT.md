# INMIN v0.4 固定硬體 Mapping 實驗

全部推薦均經完整資源日曆／流量／容量／能量 oracle 驗證。Neural replay-Q 是 gamma=0 的單步情境式 RL，內層 optimizer 與 warmup 收益不能等同於已學會的 policy 收益。

|Method|Full PPA|Cost 改善 %|Latency 改善 %|Energy 改善 %|Warmup 後改善 %|SGD updates|Charged s|
|---|---:|---:|---:|---:|---:|---:|---:|
|replay_rl|64|8.998424059516585|24.61031843352718|31.5539058070475|4.085200537989097|1888|919.5689181999769|
|random|64|9.130225518294688|17.538804270932285|28.865763828193312|4.22411802767928|0|936.5458047001157|
|sa|58|8.78687053642464|29.28046617189373|33.44774601863073|5.765678170429778|0|940.0232420000248|

SGD updates 不等於新的 PPA；所有 compiler reject／timeout 留在 events.jsonl 與 worker/accounting.json。
固定架構與 Fusion Off；不能把結果當成架構搜尋收益、原版 Tangram/Gemini 實作的直接勝負或 silicon 量測。
同一個 full query ceiling 不代表每方法實際完成數相同；同時讀取查詢與牆鐘。
