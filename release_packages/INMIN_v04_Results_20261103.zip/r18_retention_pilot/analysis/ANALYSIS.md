# INMIN v0.4 數字審計

Audit passed: True
Run status: completed

|Method|Full PPA|Cost 改善 %|Latency 改善 %|Energy 改善 %|PPA/min（搜尋）|最後10步 entropy|
|---|---:|---:|---:|---:|---:|---:|
|replay_rl|64|8.998424|24.610318|31.553906|4.229396|0.742037|
|random|64|9.130226|17.538804|28.865764|4.148933|1.000000|
|sa|58|8.786871|29.280466|33.447746|3.732675|1.000000|

## Policy 的未見候選驗證

```json
{
  "status": "measured_control_trials_excluded_from_training",
  "initial": {
    "n": 92,
    "spearman": -0.3464852118428556,
    "pairwise_concordance": 0.38103201146679405,
    "mse": 38.46024672029114,
    "selected_top_quartile_mean_utility": -1.099201466296877,
    "all_mean_utility": 1.0989200950202864
  },
  "final": {
    "n": 92,
    "spearman": 0.7649769585253456,
    "pairwise_concordance": 0.7845198279980888,
    "mse": 18.735606321810963,
    "selected_top_quartile_mean_utility": 7.090299757319563,
    "all_mean_utility": 1.0989200950202864
  },
  "measured_bottleneck_mask_mean_abs_q_change": 0.9134244322776794,
  "measured_bottleneck_mask_max_abs_q_change": 3.348168134689331,
  "interpretation": "Unseen completed control PPA tests ranking generalization. Feature masking measures influence, not causal search benefit. Contexts may differ between methods.",
  "offline_feature_ablation": {
    "measured_features_on": {
      "n": 92,
      "spearman": 0.7649769585253456,
      "pairwise_concordance": 0.7845198279980888,
      "mse": 18.735606321810963,
      "selected_top_quartile_mean_utility": 7.090299757319563,
      "all_mean_utility": 1.0989200950202864
    },
    "reconstructed_final_max_abs_difference": 0.0,
    "measured_features_off": {
      "n": 92,
      "spearman": 0.772606075551377,
      "pairwise_concordance": 0.7902532250358337,
      "mse": 20.037924507163467,
      "selected_top_quartile_mean_utility": 7.144851910481211,
      "all_mean_utility": 1.0989200950202864
    },
    "wall_s": 3.8397164000198245,
    "additional_physical_ppa": 0,
    "training_trials": 59,
    "interpretation": "Fixed-data prediction ablation only. Does not establish a causal on-policy search win and does not train the saved search policy."
  }
}
```

共同 query/time 預算的結果見 equal_queries.csv / equal_time.csv；全步數值曲線見 curves.csv。
沒有產生圖片。未見候選排序與 feature mask 只是模型行為證據；實際搜尋勝負以相同預算的完整 PPA 結果為準。
SGD 更新次數不是 PPA 次數；內層最佳化、warmup 與 RL 選擇的效果必須分開歸因。
- legacy development cohort: source seed path was external; newer cohorts freeze seed inputs too
