"""Prediction-only held-out control PPA audit; no oracle calls or policy updates."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

def read(p):return json.loads(p.read_text(encoding='utf-8'))
def events(p):return [json.loads(line) for line in p.read_text(encoding='utf-8').splitlines()]

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--train',type=Path,required=True);p.add_argument('--test',type=Path,required=True)
p.add_argument('--out',type=Path,required=True);args=p.parse_args()
train,test=args.train.resolve(),args.test.resolve()
if read(train/'status.json')['status']!='completed':raise ValueError('training run must be complete')
tc,vc=read(train/'effective_config.json'),read(test/'effective_config.json')
tm,vm=read(train/'common.json'),read(test/'common.json')
if tc['objective']!=vc['objective'] or tc['bottleneck_features']!=vc['bottleneck_features']:
    raise ValueError('objective/features differ')
if tm['initial_state']!=vm['initial_state']:raise ValueError('initial state differs')
for side,folder in ((tm,train),(vm,test)):
    manifest=read(folder/'source_snapshot_manifest.json')
    for rel,digest in manifest['files'].items():
        if hashlib.sha256((folder/'source_snapshot'/rel).read_bytes()).hexdigest()!=digest:raise ValueError('source mismatch')
for key in ('latency_s','energy_j','power_w','area_mm2','executed_macs','dram_read_bytes','noc_hop_bytes','nop_hop_bytes'):
    if tm['metrics'][key]!=vm['metrics'][key] or tm['reference'][key]!=vm['reference'][key]:raise ValueError('physical reference differs')
sys.path.insert(0,str(train/'source_snapshot'))
sys.path.insert(0,str(train/'source_snapshot/scripts'))
from analyze_replay_mapping import ranking_metrics
from simple_rapidchiplet.hybrid.replay_q import ReplayQ
import numpy as np
training=events(train/'replay_rl/events.jsonl')
seen={r['state_hash'] for r in training if r['policy_update']}
holdout=[]
for method in ('random','sa','greedy'):
    path=test/method/'events.jsonl'
    if path.exists():holdout += [r for r in events(path) if r.get('utility') is not None and r['new_full_ppa']==1 and r['state_hash'] not in seen]
holdout=list({r['state_hash']:r for r in holdout}.values())
if not holdout:raise ValueError('no unseen test trials')
x=np.asarray([r['features'] for r in holdout],dtype=np.float32);y=np.asarray([r['utility'] for r in holdout])
ck=read(train/'replay_rl/checkpoint.json')
initial,final=ReplayQ(x.shape[1],tc['seed']),ReplayQ(x.shape[1],tc['seed'])
initial.load(train/'replay_rl/policy_initial.pt');final.load(train/'replay_rl'/ck['policy_file'])
result=dict(train_source=read(train/'source_snapshot_manifest.json')['identity'],
    test_source=read(test/'source_snapshot_manifest.json')['identity'],
    initial=ranking_metrics(initial.predict(x),y),final=ranking_metrics(final.predict(x),y),
    training_physical_trials=len(seen),test_state_hashes=[r['state_hash'] for r in holdout],
    additional_physical_ppa=0,policy_updates_performed=0,
    interpretation='Same-workload exploratory prediction test across oracle revisions with identical checked physical references. Control labels never train this policy; not a search win or cross-model generalization.')
args.out.parent.mkdir(parents=True,exist_ok=True)
args.out.write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='test_state_hashes'}))
